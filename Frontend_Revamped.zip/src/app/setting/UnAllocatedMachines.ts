export class Machine {
  MachineID: string;
  LineID: string;
  MachineType: string;
  MachineFunctionality: string;
  RatedSpeed: string;
  FactoryID: string;
  constructor() {
    this.MachineID = 'null';
    this.LineID = 'null';
    this.MachineType = 'null';
    this.MachineFunctionality = 'null';
    this.RatedSpeed = 'null';
    this.FactoryID = 'null';
  }
}
