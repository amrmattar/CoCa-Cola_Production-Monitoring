export interface SelectedModel
{
  text?:string;
  value?:number;
  id?:string;
}
