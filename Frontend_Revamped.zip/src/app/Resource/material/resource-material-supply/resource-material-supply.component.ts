import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resource-material-supply',
  templateUrl: './resource-material-supply.component.html',
  styleUrls: ['./resource-material-supply.component.scss']
})
export class ResourceMaterialSupplyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
