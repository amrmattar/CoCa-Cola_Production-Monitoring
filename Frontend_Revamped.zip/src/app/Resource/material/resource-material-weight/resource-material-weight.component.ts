import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resource-material-weight',
  templateUrl: './resource-material-weight.component.html',
  styleUrls: ['./resource-material-weight.component.scss']
})
export class ResourceMaterialWeightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
