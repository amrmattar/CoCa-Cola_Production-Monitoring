import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resource-material-consumption',
  templateUrl: './resource-material-consumption.component.html',
  styleUrls: ['./resource-material-consumption.component.scss']
})
export class ResourceMaterialConsumptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
