import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-man-power',
  templateUrl: './man-power.component.html',
  styleUrls: ['./man-power.component.scss']
})
export class ManPowerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
